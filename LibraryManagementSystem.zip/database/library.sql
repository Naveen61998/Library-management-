CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

CREATE TABLE IF NOT EXISTS books (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(120) NOT NULL,
  category VARCHAR(80),
  isbn VARCHAR(30) UNIQUE,
  quantity INT NOT NULL DEFAULT 1,
  available_quantity INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS members (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(30),
  address VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS issues (
  id INT PRIMARY KEY AUTO_INCREMENT,
  book_id INT NOT NULL,
  member_id INT NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE,
  fine DECIMAL(10,2) DEFAULT 0,
  status ENUM('ISSUED','RETURNED') DEFAULT 'ISSUED',
  FOREIGN KEY (book_id) REFERENCES books(id),
  FOREIGN KEY (member_id) REFERENCES members(id)
);

INSERT IGNORE INTO books(title,author,category,isbn,quantity,available_quantity)
VALUES ('Clean Code','Robert C. Martin','Programming','9780132350884',3,3);

INSERT IGNORE INTO books(title,author,category,isbn,quantity,available_quantity)
VALUES ('Effective Java','Joshua Bloch','Programming','9780134685991',2,2);

INSERT IGNORE INTO members(name,email,phone,address)
VALUES ('Demo Member','demo@example.com','9000000000','Hyderabad');
